// The Cozy Loft — Shory HQ interior.
// Lifted from the original prototype; wrapped so it can be composed
// into the larger Al Maryah neighborhood. The loft stays at the origin;
// everything else in the world is positioned relative to it.
//
// Animations kept for Phase 1a: dog drives his toy car in a gentle oval,
// cat walks a figure-8 on the rug, dust motes drift. These give HQ a
// lived-in feel when the camera looks in from the street.

import { SHORY_IMG } from '../assets/shory-logo.js';

export function buildLoft(scene, THREE, M) {
  const FLOOR = 16;

  // --- Floor planks ---
  const planks = 14;
  for (let i = 0; i < planks; i++) {
    const p = new THREE.Mesh(
      new THREE.BoxGeometry(FLOOR, 0.1, FLOOR / planks),
      i % 2 === 0 ? M.floorLt : M.floorDk
    );
    p.position.set(0, 0.01, -FLOOR / 2 + (i + 0.5) * FLOOR / planks);
    p.receiveShadow = true;
    scene.add(p);
  }

  // --- Interior walls (back + left only — the other two sides open to street) ---
  const backWall = new THREE.Mesh(new THREE.BoxGeometry(FLOOR, 8, 0.2), M.wall);
  backWall.position.set(0, 4, -FLOOR / 2);
  backWall.receiveShadow = true;
  scene.add(backWall);

  const leftWall = new THREE.Mesh(new THREE.BoxGeometry(0.2, 8, FLOOR), M.wall);
  leftWall.position.set(-FLOOR / 2, 4, 0);
  leftWall.receiveShadow = true;
  scene.add(leftWall);

  // --- Ceiling beams ---
  const beamMat = new THREE.MeshStandardMaterial({ color: '#5b3d26', roughness: 0.85 });
  [-2, 2].forEach(bz => {
    const b = new THREE.Mesh(new THREE.BoxGeometry(FLOOR, 0.3, 0.35), beamMat);
    b.position.set(0, 7.3, bz);
    b.castShadow = true;
    scene.add(b);
  });

  // --- Windows on back wall (two panels flanking the Shory poster) ---
  for (let w of [0, 2]) {
    const g = new THREE.Group();
    g.position.set(-4.5 + w * 3.2, 4, -FLOOR / 2 + 0.12);
    scene.add(g);
    const fm = new THREE.MeshStandardMaterial({ color: '#2b2b2b', roughness: 0.5 });
    g.add(new THREE.Mesh(new THREE.BoxGeometry(2.8, 5.2, 0.15), fm));
    const glass = new THREE.Mesh(new THREE.BoxGeometry(2.6, 5.0, 0.05), M.glass);
    glass.position.z = 0.08;
    g.add(glass);
    for (let r = 1; r <= 3; r++) {
      const m = new THREE.Mesh(new THREE.BoxGeometry(2.6, 0.06, 0.1), fm);
      m.position.set(0, 2.5 - r * 1.25, 0.1);
      g.add(m);
    }
    const vm = new THREE.Mesh(new THREE.BoxGeometry(0.06, 5.0, 0.1), fm);
    vm.position.set(0, 0, 0.1);
    g.add(vm);
  }

  // --- Shory poster (centre of back wall) ---
  const posterGroup = new THREE.Group();
  posterGroup.position.set(-4.5 + 3.2, 4, -FLOOR / 2 + 0.15);
  scene.add(posterGroup);
  const posterFrame = new THREE.Mesh(new THREE.BoxGeometry(2.9, 2.0, 0.12), M.frame);
  posterFrame.castShadow = true;
  posterGroup.add(posterFrame);
  const loader = new THREE.TextureLoader();
  loader.load(SHORY_IMG, (tex) => {
    tex.encoding = THREE.sRGBEncoding;
    const posterMat = new THREE.MeshStandardMaterial({ map: tex, roughness: 0.8 });
    const poster = new THREE.Mesh(new THREE.PlaneGeometry(2.6, 1.72), posterMat);
    poster.position.z = 0.07;
    posterGroup.add(poster);
  });

  // --- Desk + chair + monitor ---
  const DX = -3, DZ = -5.2;
  const deskTop = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.12, 1.8), M.woodLt);
  deskTop.position.set(DX, 2.2, DZ);
  deskTop.castShadow = deskTop.receiveShadow = true;
  scene.add(deskTop);
  [[-2.1,-0.8],[2.1,-0.8],[-2.1,0.8],[2.1,0.8]].forEach(([lx, lz]) => {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.1, 2.2, 0.1), M.metal);
    leg.position.set(DX + lx, 1.1, DZ + lz);
    leg.castShadow = true;
    scene.add(leg);
  });
  const monStand = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.5, 0.2), M.metal);
  monStand.position.set(DX, 2.55, DZ - 0.4);
  monStand.castShadow = true;
  scene.add(monStand);
  const mon = new THREE.Mesh(new THREE.BoxGeometry(2.4, 1.4, 0.08), M.black);
  mon.position.set(DX, 3.3, DZ - 0.4);
  mon.castShadow = true;
  scene.add(mon);
  const monScreen = new THREE.Mesh(new THREE.PlaneGeometry(2.25, 1.25), M.screen);
  monScreen.position.set(DX, 3.3, DZ - 0.355);
  scene.add(monScreen);
  const kb = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.05, 0.35), M.black);
  kb.position.set(DX, 2.29, DZ + 0.2);
  scene.add(kb);
  const mug = new THREE.Mesh(
    new THREE.CylinderGeometry(0.12, 0.12, 0.25, 20),
    new THREE.MeshStandardMaterial({ color: '#e8e3db' })
  );
  mug.position.set(DX + 1.2, 2.4, DZ + 0.3);
  mug.castShadow = true;
  scene.add(mug);

  const chair = new THREE.Group();
  chair.position.set(DX, 0, -3.4);
  scene.add(chair);
  const seat = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.15, 1.1), M.black);
  seat.position.y = 1.3;
  seat.castShadow = true;
  chair.add(seat);
  const backR = new THREE.Mesh(new THREE.BoxGeometry(1.1, 1.4, 0.12), M.black);
  backR.position.set(0, 2.0, -0.5);
  backR.castShadow = true;
  chair.add(backR);
  const chairStem = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 1.2, 12), M.metal);
  chairStem.position.y = 0.7;
  chair.add(chairStem);
  const chairBase = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.08, 20), M.metal);
  chairBase.position.y = 0.1;
  chair.add(chairBase);

  // --- Couch + pillows ---
  const couch = new THREE.Group();
  couch.position.set(5, 0, 2.5);
  couch.rotation.y = -Math.PI / 2;
  scene.add(couch);
  const couchBase = new THREE.Mesh(new THREE.BoxGeometry(4, 0.6, 1.6), M.couch);
  couchBase.position.y = 0.75;
  couchBase.castShadow = couchBase.receiveShadow = true;
  couch.add(couchBase);
  const couchSeat = new THREE.Mesh(new THREE.BoxGeometry(3.8, 0.35, 1.4), M.couch);
  couchSeat.position.y = 1.25;
  couchSeat.castShadow = true;
  couch.add(couchSeat);
  const couchBack = new THREE.Mesh(new THREE.BoxGeometry(4, 1.2, 0.4), M.couch);
  couchBack.position.set(0, 1.55, -0.6);
  couchBack.castShadow = true;
  couch.add(couchBack);
  [-1.85, 1.85].forEach(ax => {
    const arm = new THREE.Mesh(new THREE.BoxGeometry(0.35, 1.1, 1.6), M.couch);
    arm.position.set(ax, 1.4, 0);
    arm.castShadow = true;
    couch.add(arm);
  });
  const p1 = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.55, 0.3), M.pillowA);
  p1.position.set(-1.2, 1.75, -0.4);
  p1.rotation.z = 0.08;
  p1.castShadow = true;
  couch.add(p1);
  const p2 = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.55, 0.3), M.pillowB);
  p2.position.set(1.0, 1.75, -0.4);
  p2.rotation.z = -0.12;
  p2.castShadow = true;
  couch.add(p2);

  // --- Rug + coffee table ---
  const rug = new THREE.Mesh(new THREE.CircleGeometry(2.4, 32), M.rug);
  rug.rotation.x = -Math.PI / 2;
  rug.position.set(1, 0.06, 1);
  rug.receiveShadow = true;
  scene.add(rug);

  const cTable = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.08, 0.9), M.wood);
  cTable.position.set(1, 0.9, 1);
  cTable.castShadow = cTable.receiveShadow = true;
  scene.add(cTable);
  [[-0.7,-0.4],[0.7,-0.4],[-0.7,0.4],[0.7,0.4]].forEach(([lx, lz]) => {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.9, 0.08), M.wood);
    leg.position.set(1 + lx, 0.45, 1 + lz);
    leg.castShadow = true;
    scene.add(leg);
  });

  // --- Pendant lamp ---
  const cord = new THREE.Mesh(
    new THREE.CylinderGeometry(0.015, 0.015, 2.8, 8),
    new THREE.MeshStandardMaterial({ color: '#1a1a1a' })
  );
  cord.position.set(0, 5.8, 0);
  scene.add(cord);
  const shade = new THREE.Mesh(new THREE.ConeGeometry(0.5, 0.7, 24, 1, true), M.lampShade);
  shade.position.set(0, 4.2, 0);
  scene.add(shade);
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.18, 16, 16), M.lampBulb);
  bulb.position.set(0, 4.0, 0);
  scene.add(bulb);

  // --- Plants ---
  function plant(x, z, s = 1) {
    const g = new THREE.Group();
    g.position.set(x, 0, z);
    g.scale.setScalar(s);
    const pot = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.25, 0.45, 16), M.pot);
    pot.position.y = 0.28;
    pot.castShadow = true;
    g.add(pot);
    for (let i = 0; i < 5; i++) {
      const leaf = new THREE.Mesh(
        new THREE.IcosahedronGeometry(0.35 + Math.random() * 0.15, 0),
        i % 2 === 0 ? M.leaf : M.leafLt
      );
      leaf.position.set((Math.random() - 0.5) * 0.3, 0.7 + Math.random() * 0.6, (Math.random() - 0.5) * 0.3);
      leaf.scale.y = 1.6;
      leaf.castShadow = true;
      g.add(leaf);
    }
    return g;
  }
  scene.add(plant(-6.5, -6, 1.1));
  scene.add(plant(5.5, -6.2, 0.85));
  scene.add(plant(-5.5, 5, 0.95));

  // --- Bookshelf ---
  const shelf = new THREE.Group();
  shelf.position.set(-FLOOR / 2 + 0.3, 0, 3);
  scene.add(shelf);
  const shelfFrame = new THREE.Mesh(new THREE.BoxGeometry(0.3, 5.2, 2.8), M.wood);
  shelfFrame.position.set(0, 2.6, 0);
  shelfFrame.castShadow = true;
  shelf.add(shelfFrame);
  const bookColors = ['#7a3b2a','#2a4a6a','#3a6a4a','#8a5a2a','#4a2a4a','#7a7a3a'];
  for (let r = 0; r < 4; r++) {
    for (let i = 0; i < 8; i++) {
      const h = 0.55 + Math.random() * 0.2;
      const b = new THREE.Mesh(
        new THREE.BoxGeometry(0.22, h, 0.15 + Math.random() * 0.08),
        new THREE.MeshStandardMaterial({ color: bookColors[Math.floor(Math.random() * bookColors.length)], roughness: 0.85 })
      );
      b.position.set(0.22, 0.9 + r * 1.1 + h / 2, -1.2 + i * 0.3);
      b.castShadow = true;
      shelf.add(b);
    }
  }

  // --- Dog's toy car ---
  const car = new THREE.Group();
  scene.add(car);
  const chassis = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.35, 0.95), M.carBody);
  chassis.position.y = 0.38;
  chassis.castShadow = true;
  car.add(chassis);
  const hood = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.2, 0.85), M.carBody);
  hood.position.set(0.55, 0.65, 0);
  hood.castShadow = true;
  car.add(hood);
  const windshield = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.45, 0.8), M.carWindow);
  windshield.position.set(0.25, 0.78, 0);
  windshield.rotation.z = -0.3;
  car.add(windshield);
  const trunk = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 0.9), M.carBody);
  trunk.position.set(-0.65, 0.80, 0);
  trunk.castShadow = true;
  car.add(trunk);
  const frontBump = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.9), M.metal);
  frontBump.position.set(0.92, 0.35, 0);
  car.add(frontBump);
  const backBump = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.12, 0.9), M.metal);
  backBump.position.set(-0.92, 0.35, 0);
  car.add(backBump);
  const hlGeo = new THREE.SphereGeometry(0.09, 12, 12);
  [-0.3, 0.3].forEach(zz => {
    const hl = new THREE.Mesh(hlGeo, M.headlamp);
    hl.position.set(0.95, 0.45, zz);
    car.add(hl);
  });
  const tlGeo = new THREE.BoxGeometry(0.05, 0.1, 0.15);
  [-0.35, 0.35].forEach(zz => {
    const tl = new THREE.Mesh(tlGeo, M.tailLight);
    tl.position.set(-0.94, 0.5, zz);
    car.add(tl);
  });
  const steering = new THREE.Mesh(new THREE.TorusGeometry(0.11, 0.02, 8, 20), M.black);
  steering.rotation.y = Math.PI / 2;
  steering.position.set(0.2, 0.85, 0);
  car.add(steering);
  const wheels = [];
  const wheelGeo = new THREE.CylinderGeometry(0.22, 0.22, 0.14, 18);
  [[0.55,-0.45],[0.55,0.45],[-0.55,-0.45],[-0.55,0.45]].forEach(([wx, wz]) => {
    const wg = new THREE.Group();
    wg.position.set(wx, 0.22, wz);
    const tire = new THREE.Mesh(wheelGeo, M.tire);
    tire.rotation.x = Math.PI / 2;
    tire.castShadow = true;
    wg.add(tire);
    const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.16, 10), M.rim);
    rim.rotation.x = Math.PI / 2;
    wg.add(rim);
    car.add(wg);
    wheels.push(wg);
  });

  // --- Dog ---
  const dog = new THREE.Group();
  scene.add(dog);
  const dogBodyG = new THREE.Group();
  dog.add(dogBodyG);
  const dogTorso = new THREE.Mesh(new THREE.SphereGeometry(0.4, 20, 16), M.dogFur);
  dogTorso.scale.set(1.4, 0.95, 1);
  dogTorso.position.set(0, 0.75, 0);
  dogTorso.castShadow = true;
  dogBodyG.add(dogTorso);
  const dogBelly = new THREE.Mesh(new THREE.SphereGeometry(0.28, 16, 12), M.dogBelly);
  dogBelly.scale.set(1.3, 0.7, 0.9);
  dogBelly.position.set(0, 0.58, 0);
  dogBodyG.add(dogBelly);
  const dogHeadG = new THREE.Group();
  dogHeadG.position.set(0.55, 1.0, 0);
  dogBodyG.add(dogHeadG);
  const dogHead = new THREE.Mesh(new THREE.SphereGeometry(0.3, 20, 16), M.dogFur);
  dogHead.castShadow = true;
  dogHeadG.add(dogHead);
  const snout = new THREE.Mesh(new THREE.SphereGeometry(0.18, 16, 12), M.dogBelly);
  snout.scale.set(1.2, 0.8, 0.9);
  snout.position.set(0.23, -0.08, 0);
  snout.castShadow = true;
  dogHeadG.add(snout);
  const dogNose = new THREE.Mesh(new THREE.SphereGeometry(0.06, 12, 12), M.dogNose);
  dogNose.position.set(0.4, -0.05, 0);
  dogHeadG.add(dogNose);
  dogHeadG.add(makeEye(THREE, M, 0.045, 0.19, 0.08, -0.14));
  dogHeadG.add(makeEye(THREE, M, 0.045, 0.19, 0.08, 0.14));
  const earGeoD = new THREE.SphereGeometry(0.12, 12, 10);
  const dogEarL = new THREE.Mesh(earGeoD, M.dogFur);
  dogEarL.scale.set(0.5, 1.2, 0.8);
  dogEarL.position.set(-0.15, 0.12, -0.28);
  dogHeadG.add(dogEarL);
  const dogEarR = new THREE.Mesh(earGeoD, M.dogFur);
  dogEarR.scale.set(0.5, 1.2, 0.8);
  dogEarR.position.set(-0.15, 0.12, 0.28);
  dogHeadG.add(dogEarR);
  const collar = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.04, 8, 20), M.collar);
  collar.rotation.y = Math.PI / 2;
  collar.position.set(0.35, 0.88, 0);
  dogBodyG.add(collar);
  const tag = new THREE.Mesh(new THREE.CircleGeometry(0.05, 16), M.tag);
  tag.position.set(0.43, 0.78, 0);
  dogBodyG.add(tag);
  const dogLegs = [];
  [[0.28,-0.28],[0.28,0.28],[-0.28,-0.28],[-0.28,0.28]].forEach(([lx, lz]) => {
    const legG = new THREE.Group();
    legG.position.set(lx, 0.55, lz);
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 0.55, 10), M.dogFur);
    leg.position.y = -0.22;
    leg.castShadow = true;
    legG.add(leg);
    dogBodyG.add(legG);
    dogLegs.push(legG);
  });
  const dogTailG = new THREE.Group();
  dogTailG.position.set(-0.45, 0.85, 0);
  dogBodyG.add(dogTailG);
  const dogTail = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.03, 0.5, 10), M.dogFur);
  dogTail.position.set(-0.2, 0.1, 0);
  dogTail.rotation.z = Math.PI / 2.5;
  dogTail.castShadow = true;
  dogTailG.add(dogTail);

  // --- Cat ---
  const cat = new THREE.Group();
  scene.add(cat);
  const catBodyG = new THREE.Group();
  cat.add(catBodyG);
  const catTorso = new THREE.Mesh(new THREE.SphereGeometry(0.32, 20, 16), M.catFur);
  catTorso.scale.set(1.3, 0.85, 1);
  catTorso.position.set(0, 0.45, 0);
  catTorso.castShadow = true;
  catBodyG.add(catTorso);
  const catBelly = new THREE.Mesh(new THREE.SphereGeometry(0.22, 16, 12), M.catBelly);
  catBelly.scale.set(1.1, 0.6, 0.85);
  catBelly.position.set(0, 0.35, 0);
  catBodyG.add(catBelly);
  const catHeadG = new THREE.Group();
  catHeadG.position.set(0.38, 0.6, 0);
  catBodyG.add(catHeadG);
  const catHead = new THREE.Mesh(new THREE.SphereGeometry(0.22, 20, 16), M.catFur);
  catHead.castShadow = true;
  catHeadG.add(catHead);
  const catEarGeo = new THREE.ConeGeometry(0.08, 0.18, 12);
  const catEarL = new THREE.Mesh(catEarGeo, M.catFur);
  catEarL.position.set(-0.02, 0.19, -0.11);
  catHeadG.add(catEarL);
  const catEarR = new THREE.Mesh(catEarGeo, M.catFur);
  catEarR.position.set(-0.02, 0.19, 0.11);
  catHeadG.add(catEarR);
  catHeadG.add(makeEye(THREE, M, 0.035, 0.17, 0.04, -0.09, true));
  catHeadG.add(makeEye(THREE, M, 0.035, 0.17, 0.04, 0.09, true));
  const catNose = new THREE.Mesh(new THREE.SphereGeometry(0.022, 8, 8), M.catNose);
  catNose.position.set(0.21, -0.02, 0);
  catHeadG.add(catNose);
  const catLegs = [];
  [[0.2,-0.17],[0.2,0.17],[-0.2,-0.17],[-0.2,0.17]].forEach(([lx, lz]) => {
    const legG = new THREE.Group();
    legG.position.set(lx, 0.33, lz);
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 0.33, 8), M.catFur);
    leg.position.y = -0.14;
    leg.castShadow = true;
    legG.add(leg);
    catBodyG.add(legG);
    catLegs.push(legG);
  });
  const catTailG = new THREE.Group();
  catTailG.position.set(-0.35, 0.55, 0);
  catBodyG.add(catTailG);
  const tailSegs = [];
  for (let i = 0; i < 5; i++) {
    const s = new THREE.Mesh(new THREE.SphereGeometry(0.055, 10, 8), M.catFur);
    s.castShadow = true;
    catTailG.add(s);
    tailSegs.push(s);
  }

  // --- Dust motes ---
  const dustCount = 100;
  const dustGeo = new THREE.BufferGeometry();
  const dustPos = new Float32Array(dustCount * 3);
  const dustSeed = [];
  for (let i = 0; i < dustCount; i++) {
    dustPos[i * 3] = (Math.random() - 0.5) * 14;
    dustPos[i * 3 + 1] = Math.random() * 6 + 0.5;
    dustPos[i * 3 + 2] = (Math.random() - 0.5) * 14;
    dustSeed.push(Math.random() * Math.PI * 2);
  }
  dustGeo.setAttribute('position', new THREE.BufferAttribute(dustPos, 3));
  const dust = new THREE.Points(
    dustGeo,
    new THREE.PointsMaterial({ color: '#fff3d8', size: 0.06, transparent: true, opacity: 0.5, sizeAttenuation: true })
  );
  scene.add(dust);

  return {
    car, wheels, dog, dogBodyG, dogHeadG, dogLegs, dogTailG, dogEarL, dogEarR,
    cat, catLegs, catTailG, tailSegs, dust, dustSeed, dustCount,
    monScreen, monitor: { x: DX, y: 3.3, z: DZ - 0.355 },
  };
}

function makeEye(THREE, M, r, x, y, z, green = false) {
  const e = new THREE.Mesh(new THREE.SphereGeometry(r, 12, 12), green ? M.eyeGreen : M.eye);
  e.position.set(x, y, z);
  return e;
}

// Drive the loft animation each frame. Dog sits in his toy car doing an oval
// on the rug. Cat walks a figure-8. Dust drifts. These continue regardless of
// what's happening in the wider world — HQ is alive.
export function tickLoft(refs, t, dt) {
  const { car, wheels, dog, dogBodyG, dogHeadG, dogLegs, dogTailG, dogEarL, dogEarR,
          cat, catLegs, catTailG, tailSegs, dust, dustSeed, dustCount } = refs;

  // Dust float
  const arr = dust.geometry.attributes.position.array;
  for (let i = 0; i < dustCount; i++) {
    arr[i * 3 + 1] += Math.sin(t * 0.6 + dustSeed[i]) * 0.002;
    arr[i * 3]     += Math.cos(t * 0.4 + dustSeed[i]) * 0.0015;
  }
  dust.geometry.attributes.position.needsUpdate = true;

  // Car on oval
  refs._carU = ((refs._carU || 0) + dt * 0.10) % 1;
  const u = refs._carU;
  const a = 2 * Math.PI * u;
  const cx = 0.8 + 3.2 * Math.cos(a);
  const cz = 2.2 + 2.2 * Math.sin(a);
  const dx = -3.2 * Math.sin(a);
  const dz = 2.2 * Math.cos(a);
  const h = Math.atan2(dx, dz);
  car.position.set(cx, 0, cz);
  car.rotation.y = h;
  wheels.forEach(w => w.rotation.x -= dt * 8);

  // Dog in driver's seat
  dog.scale.setScalar(0.55);
  dog.position.set(cx, 0.35, cz);
  dog.rotation.y = h;
  dogBodyG.rotation.set(0, 0, 0);
  dogHeadG.rotation.z = -0.1;
  dogLegs.forEach(l => l.rotation.x = 0);
  dogTailG.rotation.x = Math.sin(t * 10) * 0.8;
  dogEarL.rotation.x = -0.3 + Math.sin(t * 5) * 0.15;
  dogEarR.rotation.x = -0.3 + Math.sin(t * 5 + 0.4) * 0.15;

  // Cat figure-8 on rug
  refs._catU = ((refs._catU || 0) + dt * 0.06) % 1;
  const cu = refs._catU;
  const ca = 2 * Math.PI * cu;
  const catX = 1.0 + 1.7 * Math.sin(ca * 2);
  const catZ = 1.0 + 1.4 * Math.sin(ca);
  const cdx = 3.4 * Math.cos(ca * 2);
  const cdz = 1.4 * Math.cos(ca);
  cat.scale.setScalar(0.7);
  cat.position.set(catX, 0, catZ);
  cat.rotation.y = Math.atan2(cdx, cdz);
  const cs = t * 6;
  catLegs[0].rotation.x = Math.sin(cs) * 0.5;
  catLegs[3].rotation.x = Math.sin(cs) * 0.5;
  catLegs[1].rotation.x = -Math.sin(cs) * 0.5;
  catLegs[2].rotation.x = -Math.sin(cs) * 0.5;
  tailSegs.forEach((s, i) => {
    const phase = t * 3 + i * 0.5;
    s.position.set(-0.1 * (i + 1), 0.05 + i * 0.02, Math.sin(phase) * 0.1);
  });
  catTailG.rotation.y = Math.sin(t * 2) * 0.3;
}
