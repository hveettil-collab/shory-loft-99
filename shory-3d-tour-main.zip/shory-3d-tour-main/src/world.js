// Al Maryah Island neighborhood — Shory HQ + three destinations
// (Café Mira, Residential Tower, Parking Lot). Al Maryah is Abu Dhabi's
// calm, cream-stone + glass business/residential island — perfect visual
// fit for the Cozy Loft palette. We keep it compact (~80x80u) around a
// crossroads, with a sliver of the Khor Al Maryah channel visible to
// the east so the player knows they're on an island.
//
// World axes (camera-up is +Y):
//   +X = east (toward water)
//   +Z = south (toward parking lot, away from HQ)
//   Origin (0,0,0) = Shory HQ ground floor (loft center)

export const DESTINATIONS = {
  hq:      { name: 'Shory HQ',          pos: [0, 0, 0],    radius: 6 },
  cafe:    { name: 'Café Mira',         pos: [26, 0, 28],  radius: 5 },
  tower:   { name: "Friend's Tower",    pos: [-26, 0, 28], radius: 5 },
  parking: { name: 'Al Maryah Parking', pos: [0, 0, 46],   radius: 6 },
};

export function buildWorld(scene, THREE, M) {
  const group = new THREE.Group();
  scene.add(group);

  // --- Ground plaza (huge cream slab) ---
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(160, 160), M.ground);
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.01;
  ground.receiveShadow = true;
  group.add(ground);

  // --- Water sliver to the far east (Khor Al Maryah) ---
  const water = new THREE.Mesh(new THREE.PlaneGeometry(40, 200), M.water);
  water.rotation.x = -Math.PI / 2;
  water.position.set(70, -0.02, 0);
  water.receiveShadow = true;
  group.add(water);
  // Soft edge: a low cream seawall between plaza and water
  const seawall = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.5, 200), M.curb);
  seawall.position.set(50, 0.25, 0);
  seawall.castShadow = seawall.receiveShadow = true;
  group.add(seawall);

  // --- Streets (two crossing roads) ---
  // Al Maryah Promenade runs E-W at Z = +18
  // Al Falah St runs N-S at X = 0 (goes through HQ plaza → parking lot)
  buildRoad(group, THREE, M, { x: 0, z: 18, w: 120, h: 8, axis: 'ew' });
  buildRoad(group, THREE, M, { x: 0, z: 32, w: 8, h: 32, axis: 'ns' });

  // --- HQ exterior (wraps the loft; second floor + signboard) ---
  buildHQExterior(group, THREE, M);

  // --- Destinations ---
  buildCafe(group, THREE, M, DESTINATIONS.cafe.pos);
  buildTower(group, THREE, M, DESTINATIONS.tower.pos);
  buildParkingLot(group, THREE, M, DESTINATIONS.parking.pos);

  // --- Ambient props: palms, shrubs, streetlamps ---
  // Palms along the promenade
  for (let px = -50; px <= 50; px += 10) {
    if (Math.abs(px) < 6) continue; // skip over the crossing
    palm(group, THREE, M, px, 14);
    palm(group, THREE, M, px, 22);
  }
  // Palms flanking Al Falah st
  [38, 52].forEach(pz => { palm(group, THREE, M, -5, pz); palm(group, THREE, M, 5, pz); });
  // Extra palms around HQ plaza
  palm(group, THREE, M, 10, 10, 0.9);
  palm(group, THREE, M, -10, 10, 0.9);
  // Shrubs
  for (let i = 0; i < 14; i++) {
    const x = (Math.random() - 0.5) * 100;
    const z = (Math.random() - 0.5) * 60 + 20;
    // Avoid roads & buildings — simple exclusion zones
    if (Math.abs(z - 18) < 5 || Math.abs(x) < 5 && z < 40) continue;
    if (Math.abs(x - 26) < 8 && Math.abs(z - 28) < 8) continue;
    if (Math.abs(x + 26) < 8 && Math.abs(z - 28) < 8) continue;
    shrub(group, THREE, M, x, z);
  }
  // Streetlamps at each intersection corner + along promenade
  [[-6, 12], [6, 12], [-6, 24], [6, 24],
   [-4, 32], [4, 32], [-4, 58], [4, 58]].forEach(([x, z]) => streetlamp(group, THREE, M, x, z));

  // --- Destination markers (soft cream discs; quest system will replace these) ---
  const markerMat = new THREE.MeshStandardMaterial({
    color: '#f5ecdc', emissive: '#d4c090', emissiveIntensity: 0.15,
    transparent: true, opacity: 0.65, roughness: 0.7,
  });
  [DESTINATIONS.cafe, DESTINATIONS.tower, DESTINATIONS.parking].forEach(d => {
    const disc = new THREE.Mesh(new THREE.RingGeometry(d.radius * 0.7, d.radius, 48), markerMat);
    disc.rotation.x = -Math.PI / 2;
    disc.position.set(d.pos[0], 0.02, d.pos[2]);
    group.add(disc);
  });

  return { group, lampMaterials: group.userData.lampMaterials || [] };
}

// ------------------------------------------------------------------
// Helpers
// ------------------------------------------------------------------

function buildRoad(parent, THREE, M, { x, z, w, h, axis }) {
  const roadGeo = axis === 'ew'
    ? new THREE.PlaneGeometry(w, h)
    : new THREE.PlaneGeometry(w, h);
  const road = new THREE.Mesh(roadGeo, M.road);
  road.rotation.x = -Math.PI / 2;
  road.position.set(x, 0.015, z);
  road.receiveShadow = true;
  parent.add(road);

  // Curbs
  const curbMat = M.curb;
  if (axis === 'ew') {
    const north = new THREE.Mesh(new THREE.BoxGeometry(w, 0.15, 0.3), curbMat);
    north.position.set(x, 0.075, z - h / 2);
    const south = north.clone();
    south.position.z = z + h / 2;
    north.receiveShadow = south.receiveShadow = true;
    parent.add(north, south);
    // Centre dashes
    for (let dx = -w / 2 + 2; dx <= w / 2 - 2; dx += 4) {
      const dash = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.2), M.roadLine);
      dash.rotation.x = -Math.PI / 2;
      dash.position.set(x + dx, 0.02, z);
      parent.add(dash);
    }
  } else {
    const east = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.15, h), curbMat);
    east.position.set(x + w / 2, 0.075, z);
    const west = east.clone();
    west.position.x = x - w / 2;
    east.receiveShadow = west.receiveShadow = true;
    parent.add(east, west);
    for (let dz = -h / 2 + 2; dz <= h / 2 - 2; dz += 4) {
      const dash = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 1.4), M.roadLine);
      dash.rotation.x = -Math.PI / 2;
      dash.position.set(x, 0.02, z + dz);
      parent.add(dash);
    }
  }
}

// HQ — 2-story cream building; loft occupies ground floor, signboard up top.
// The loft already provides back + left walls and the floor, so we add:
//   - A short external facade on the open sides (front + right) with big windows
//   - The second-floor slab + walls above
//   - A flat roof
//   - Shory signboard facing the promenade
function buildHQExterior(parent, THREE, M) {
  const F = 16; // loft footprint
  const floorSlab = new THREE.Mesh(new THREE.BoxGeometry(F, 0.3, F), M.facadeCream);
  floorSlab.position.set(0, 8, 0);
  floorSlab.castShadow = floorSlab.receiveShadow = true;
  parent.add(floorSlab);

  // Second floor walls
  const wallH = 5;
  const back2 = new THREE.Mesh(new THREE.BoxGeometry(F, wallH, 0.3), M.facadeCream);
  back2.position.set(0, 8 + wallH / 2, -F / 2);
  back2.castShadow = back2.receiveShadow = true;
  parent.add(back2);
  const left2 = new THREE.Mesh(new THREE.BoxGeometry(0.3, wallH, F), M.facadeCream);
  left2.position.set(-F / 2, 8 + wallH / 2, 0);
  left2.castShadow = left2.receiveShadow = true;
  parent.add(left2);
  const right2 = new THREE.Mesh(new THREE.BoxGeometry(0.3, wallH, F), M.facadeCream);
  right2.position.set(F / 2, 8 + wallH / 2, 0);
  right2.castShadow = right2.receiveShadow = true;
  parent.add(right2);
  const front2 = new THREE.Mesh(new THREE.BoxGeometry(F, wallH, 0.3), M.facadeCream);
  front2.position.set(0, 8 + wallH / 2, F / 2);
  front2.castShadow = front2.receiveShadow = true;
  parent.add(front2);

  // Glass curtain-wall panels on second floor (front + sides) — Al Maryah look
  const glassH = 3.2;
  const glassMat = M.glassPanel;
  // Front (facing +Z / promenade)
  for (let gx = -6; gx <= 6; gx += 3) {
    const g = new THREE.Mesh(new THREE.BoxGeometry(2.7, glassH, 0.08), glassMat);
    g.position.set(gx, 8 + wallH / 2, F / 2 + 0.12);
    parent.add(g);
  }
  // East side (facing water)
  for (let gz = -6; gz <= 6; gz += 3) {
    const g = new THREE.Mesh(new THREE.BoxGeometry(0.08, glassH, 2.7), glassMat);
    g.position.set(F / 2 + 0.12, 8 + wallH / 2, gz);
    parent.add(g);
  }

  // Roof (flat, slight parapet)
  const roof = new THREE.Mesh(new THREE.BoxGeometry(F + 0.4, 0.3, F + 0.4), M.facadeStone);
  roof.position.set(0, 8 + wallH + 0.15, 0);
  roof.receiveShadow = true;
  parent.add(roof);
  // Parapet
  [[F / 2 + 0.2, 0], [-F / 2 - 0.2, 0], [0, F / 2 + 0.2], [0, -F / 2 - 0.2]].forEach(([px, pz], i) => {
    const isLong = i < 2;
    const p = new THREE.Mesh(
      new THREE.BoxGeometry(isLong ? 0.25 : F + 0.5, 0.6, isLong ? F + 0.5 : 0.25),
      M.facadeStone
    );
    p.position.set(px, 8 + wallH + 0.5, pz);
    p.castShadow = true;
    parent.add(p);
  });

  // Shory sign on front of second floor
  const signBg = new THREE.Mesh(new THREE.BoxGeometry(6, 1.4, 0.15), M.signBg);
  signBg.position.set(0, 8 + wallH + 1.1, F / 2 + 0.15);
  signBg.castShadow = true;
  parent.add(signBg);
  // "SHORY" text via emissive cream rectangles (low-poly word mark)
  // S-H-O-R-Y letters as thin emissive boxes spelling it out in minimal form.
  // Keep it readable but abstract — matches low-poly language.
  const letterMat = new THREE.MeshStandardMaterial({
    color: '#f5ecdc', emissive: '#f5ecdc', emissiveIntensity: 0.8, roughness: 0.5,
  });
  const letterSpec = [
    // S
    [-2.2, 0.35, 0.45, 0.12], [-2.4, 0.1, 0.12, 0.4],
    [-2.2, 0.0, 0.45, 0.12], [-2.0, -0.25, 0.12, 0.4],
    [-2.2, -0.35, 0.45, 0.12],
    // H
    [-1.3, 0.0, 0.12, 0.9], [-0.9, 0.0, 0.12, 0.9], [-1.1, 0.0, 0.35, 0.12],
    // O
    [-0.2, 0.35, 0.45, 0.12], [-0.2, -0.35, 0.45, 0.12],
    [-0.4, 0.0, 0.12, 0.6], [0.0, 0.0, 0.12, 0.6],
    // R
    [0.55, 0.0, 0.12, 0.9], [0.75, 0.35, 0.35, 0.12],
    [0.75, 0.0, 0.35, 0.12], [0.95, 0.17, 0.12, 0.4],
    [0.95, -0.2, 0.12, 0.5],
    // Y
    [1.55, 0.25, 0.12, 0.4], [1.85, 0.25, 0.12, 0.4],
    [1.7, 0.05, 0.42, 0.12], [1.7, -0.25, 0.12, 0.5],
  ];
  letterSpec.forEach(([lx, ly, lw, lh]) => {
    const letter = new THREE.Mesh(new THREE.BoxGeometry(lw, lh, 0.05), letterMat);
    letter.position.set(lx, 8 + wallH + 1.1 + ly, F / 2 + 0.25);
    parent.add(letter);
  });

  // HQ entrance marker on plaza (soft cream rug welcoming the player out)
  const mat = new THREE.Mesh(new THREE.PlaneGeometry(4, 2), M.roadLine);
  mat.rotation.x = -Math.PI / 2;
  mat.position.set(0, 0.04, 10);
  parent.add(mat);
}

function buildCafe(parent, THREE, M, [cx, , cz]) {
  const g = new THREE.Group();
  g.position.set(cx, 0, cz);
  parent.add(g);

  // Body (single story, cream + terracotta accents)
  const body = new THREE.Mesh(new THREE.BoxGeometry(12, 5, 9), M.facadeCream);
  body.position.y = 2.5;
  body.castShadow = body.receiveShadow = true;
  g.add(body);
  // Terracotta roof-band
  const band = new THREE.Mesh(new THREE.BoxGeometry(12.4, 0.5, 9.4), M.roofTerracotta);
  band.position.y = 5.2;
  band.castShadow = true;
  g.add(band);
  // Glass front
  const front = new THREE.Mesh(new THREE.BoxGeometry(10, 3.6, 0.1), M.glassPanel);
  front.position.set(0, 2.3, -4.5 + 0.05);
  g.add(front);
  // Window mullions
  [-3.5, 0, 3.5].forEach(mx => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.12, 3.6, 0.2), M.frame);
    m.position.set(mx, 2.3, -4.5);
    g.add(m);
  });
  // Awning (terracotta)
  const awning = new THREE.Mesh(new THREE.BoxGeometry(11, 0.12, 2.4), M.awning);
  awning.position.set(0, 4.4, -5.7);
  awning.rotation.x = -0.18;
  awning.castShadow = true;
  g.add(awning);
  // "MIRA" sign above door
  const signBg = new THREE.Mesh(new THREE.BoxGeometry(3.4, 0.7, 0.1), M.signBg);
  signBg.position.set(0, 4.9, -4.48);
  g.add(signBg);
  const miraMat = new THREE.MeshStandardMaterial({
    color: '#f5ecdc', emissive: '#ffd59a', emissiveIntensity: 0.6, roughness: 0.6,
  });
  // M-I-R-A minimal letterforms
  [[-1.1, 0.12, 0.9], [-0.3, 0.12, 0.25], [0.3, 0.12, 0.9], [1.1, 0.12, 0.9]].forEach(([lx]) => {
    const l = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.42, 0.04), miraMat);
    l.position.set(lx, 4.9, -4.4);
    g.add(l);
  });
  // Outdoor chairs + round tables
  for (let i = 0; i < 3; i++) {
    const t = new THREE.Group();
    t.position.set(-4 + i * 4, 0, -7.2);
    const top = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.55, 0.1, 20), M.woodLt);
    top.position.y = 1.1;
    top.castShadow = true;
    t.add(top);
    const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.12, 1.1, 12), M.metal);
    stem.position.y = 0.55;
    t.add(stem);
    // Two chairs per table
    [-1.2, 1.2].forEach(cx2 => {
      const chair = new THREE.Group();
      chair.position.set(cx2, 0, 0.5 * (cx2 > 0 ? 1 : -1));
      const seat = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.08, 0.55), M.woodLt);
      seat.position.y = 0.55;
      seat.castShadow = true;
      chair.add(seat);
      const back = new THREE.Mesh(new THREE.BoxGeometry(0.55, 0.7, 0.08), M.woodLt);
      back.position.set(0, 0.9, -0.23 * (cx2 > 0 ? 1 : -1));
      chair.add(back);
      [[0.22, 0.22], [-0.22, 0.22], [0.22, -0.22], [-0.22, -0.22]].forEach(([lx, lz]) => {
        const leg = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.55, 0.05), M.woodLt);
        leg.position.set(lx, 0.28, lz);
        chair.add(leg);
      });
      t.add(chair);
    });
    g.add(t);
  }
  // Low seawall hint — a short bench on the east edge (suggesting the channel beyond)
  const bench = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 4), M.curb);
  bench.position.set(6.6, 0.25, 0);
  bench.castShadow = true;
  g.add(bench);
}

function buildTower(parent, THREE, M, [tx, , tz]) {
  const g = new THREE.Group();
  g.position.set(tx, 0, tz);
  parent.add(g);

  // Residential tower — 5 stories tall, glass-banded
  const H = 18;
  const body = new THREE.Mesh(new THREE.BoxGeometry(10, H, 9), M.facadeSand);
  body.position.y = H / 2;
  body.castShadow = body.receiveShadow = true;
  g.add(body);
  // Horizontal glass bands
  for (let y = 2; y < H - 1; y += 3.5) {
    const band = new THREE.Mesh(new THREE.BoxGeometry(10.2, 1.6, 9.2), M.glassPanel);
    band.position.y = y;
    g.add(band);
  }
  // Roof cap
  const cap = new THREE.Mesh(new THREE.BoxGeometry(10.6, 0.5, 9.6), M.facadeStone);
  cap.position.y = H + 0.2;
  cap.castShadow = true;
  g.add(cap);
  // Arched entrance frame (simplified — a tall opening with two columns)
  const entry = new THREE.Mesh(new THREE.BoxGeometry(3.5, 4, 0.3), M.facadeStone);
  entry.position.set(0, 2, -4.5 + 0.16);
  entry.castShadow = true;
  g.add(entry);
  const entryGlass = new THREE.Mesh(new THREE.BoxGeometry(3, 3.4, 0.1), M.glassPanel);
  entryGlass.position.set(0, 2, -4.35);
  g.add(entryGlass);
  // Small courtyard wall + date palm
  const wall = new THREE.Mesh(new THREE.BoxGeometry(6, 0.8, 0.25), M.facadeStone);
  wall.position.set(0, 0.4, -6.2);
  wall.castShadow = true;
  g.add(wall);
  palm(g, THREE, M, -2.2, -6.8, 0.9);
  palm(g, THREE, M, 2.2, -6.8, 0.9);
}

function buildParkingLot(parent, THREE, M, [px, , pz]) {
  const g = new THREE.Group();
  g.position.set(px, 0, pz);
  parent.add(g);

  // Asphalt patch
  const lot = new THREE.Mesh(new THREE.PlaneGeometry(18, 14), M.road);
  lot.rotation.x = -Math.PI / 2;
  lot.position.y = 0.02;
  lot.receiveShadow = true;
  g.add(lot);
  // Low perimeter wall (open on north side facing Al Falah st)
  const wallMat = M.facadeStone;
  const south = new THREE.Mesh(new THREE.BoxGeometry(18, 1, 0.3), wallMat);
  south.position.set(0, 0.5, 7);
  south.castShadow = true;
  g.add(south);
  const east = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1, 14), wallMat);
  east.position.set(9, 0.5, 0);
  east.castShadow = true;
  g.add(east);
  const west = east.clone();
  west.position.x = -9;
  g.add(west);
  // Painted stalls (4)
  for (let i = 0; i < 4; i++) {
    const lineMat = M.roadLine;
    const stallLineL = new THREE.Mesh(new THREE.PlaneGeometry(0.15, 4.5), lineMat);
    stallLineL.rotation.x = -Math.PI / 2;
    stallLineL.position.set(-6 + i * 4, 0.03, 2.3);
    g.add(stallLineL);
  }
  const stallFront = new THREE.Mesh(new THREE.PlaneGeometry(16.5, 0.15), M.roadLine);
  stallFront.rotation.x = -Math.PI / 2;
  stallFront.position.set(0, 0.03, 0);
  g.add(stallFront);
  // Attendant booth
  const booth = new THREE.Mesh(new THREE.BoxGeometry(2, 2.4, 2), M.facadeCream);
  booth.position.set(-8, 1.2, -6);
  booth.castShadow = true;
  g.add(booth);
  const boothRoof = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.2, 2.4), M.roofTerracotta);
  boothRoof.position.set(-8, 2.5, -6);
  boothRoof.castShadow = true;
  g.add(boothRoof);
}

function palm(parent, THREE, M, x, z, scale = 1) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.scale.setScalar(scale);
  // Trunk — slightly curved by stacking 3 segments with small tilt
  for (let i = 0; i < 3; i++) {
    const seg = new THREE.Mesh(
      new THREE.CylinderGeometry(0.22 - i * 0.03, 0.25 - i * 0.03, 1.6, 10),
      M.palmTrunk
    );
    seg.position.y = 0.8 + i * 1.55;
    seg.rotation.z = (Math.random() - 0.5) * 0.08;
    seg.castShadow = true;
    g.add(seg);
  }
  // Fronds — 7 flattened cones arranged radially
  for (let i = 0; i < 7; i++) {
    const frond = new THREE.Mesh(
      new THREE.ConeGeometry(0.35, 2.2, 6),
      M.palmFrond
    );
    const angle = (i / 7) * Math.PI * 2;
    const tilt = 0.4 + Math.random() * 0.3;
    frond.position.set(
      Math.cos(angle) * 0.9,
      5.2 + (Math.random() - 0.5) * 0.2,
      Math.sin(angle) * 0.9
    );
    frond.rotation.z = Math.cos(angle) * tilt;
    frond.rotation.x = Math.sin(angle) * tilt;
    frond.scale.set(0.5, 1, 1);
    frond.castShadow = true;
    g.add(frond);
  }
  parent.add(g);
}

function shrub(parent, THREE, M, x, z) {
  const s = new THREE.Mesh(
    new THREE.IcosahedronGeometry(0.5 + Math.random() * 0.3, 0),
    M.shrub
  );
  s.position.set(x, 0.4, z);
  s.scale.y = 0.7;
  s.castShadow = true;
  parent.add(s);
}

function streetlamp(parent, THREE, M, x, z) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  const post = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 4.5, 10), M.streetlamp);
  post.position.y = 2.25;
  post.castShadow = true;
  g.add(post);
  const arm = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.1, 0.1), M.streetlamp);
  arm.position.set(0.35, 4.4, 0);
  g.add(arm);
  const head = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.25, 0.4), M.streetlamp);
  head.position.set(0.55, 4.3, 0);
  head.castShadow = true;
  g.add(head);
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.12, 10, 10), M.lampGlow);
  bulb.position.set(0.55, 4.15, 0);
  g.add(bulb);
  parent.add(g);
}
