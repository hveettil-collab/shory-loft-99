// Animated "Buy a Shory policy" demo, rendered onto a CanvasTexture so we
// can drop it straight onto the loft's monitor screen. Four steps loop
// forever (Choose car → Your details → Compare plans → Confirmed). The
// point is ambient storytelling: glance at HQ and see the product in use.

export function createPolicySim(THREE) {
  const W = 512, H = 288;
  const canvas = document.createElement('canvas');
  canvas.width = W;
  canvas.height = H;
  const ctx = canvas.getContext('2d');

  const texture = new THREE.CanvasTexture(canvas);
  texture.encoding = THREE.sRGBEncoding;
  texture.minFilter = THREE.LinearFilter;
  texture.magFilter = THREE.LinearFilter;

  const steps = [
    { title: 'Choose your car',   dur: 2.8 },
    { title: 'Your details',      dur: 2.8 },
    { title: 'Compare plans',     dur: 2.8 },
    { title: "You're covered",    dur: 2.6 },
  ];
  const total = steps.reduce((s, x) => s + x.dur, 0);
  let baseT = null;

  function draw(t) {
    const phase = t % total;
    let acc = 0, idx = 0, localT = 0;
    for (let i = 0; i < steps.length; i++) {
      if (phase < acc + steps[i].dur) {
        idx = i;
        localT = (phase - acc) / steps[i].dur;
        break;
      }
      acc += steps[i].dur;
    }

    // Background
    ctx.fillStyle = '#f5ecdc';
    ctx.fillRect(0, 0, W, H);

    // Brand strip
    ctx.fillStyle = '#1a1915';
    ctx.fillRect(0, 0, W, 40);
    ctx.fillStyle = '#f5ecdc';
    ctx.font = 'italic 22px Georgia, serif';
    ctx.fillText('shory', 20, 28);
    ctx.fillStyle = '#a69887';
    ctx.font = '11px -apple-system, system-ui, sans-serif';
    ctx.fillText('car insurance, simplified', 90, 26);

    // Step pill
    ctx.fillStyle = '#eadfca';
    roundRect(ctx, 20, 56, 130, 24, 12);
    ctx.fill();
    ctx.fillStyle = '#6e665c';
    ctx.font = '11px -apple-system, sans-serif';
    ctx.fillText(`Step ${idx + 1} of ${steps.length}`, 30, 72);

    // Step title
    ctx.fillStyle = '#2a2620';
    ctx.font = 'italic 24px Georgia, serif';
    ctx.fillText(steps[idx].title, 20, 112);

    drawBody(idx, localT);

    // Progress bar
    const barX = 20, barY = H - 18, barW = W - 40;
    ctx.fillStyle = '#e5dbc5';
    ctx.fillRect(barX, barY, barW, 4);
    ctx.fillStyle = '#b89668';
    ctx.fillRect(barX, barY, (phase / total) * barW, 4);

    texture.needsUpdate = true;
  }

  function drawBody(idx, localT) {
    const BY = 132;
    if (idx === 0) {
      // Three car options, highlight cycles across them
      const colors = ['#e8dcc4', '#c9b78a', '#a89878'];
      const labels = ['Compact', 'Sedan', 'SUV'];
      const hi = Math.min(2, Math.floor(localT * 3.2));
      for (let i = 0; i < 3; i++) {
        const x = 30 + i * 160;
        ctx.fillStyle = colors[i];
        roundRect(ctx, x, BY, 140, 78, 10);
        ctx.fill();
        // Car silhouette
        ctx.strokeStyle = '#2a2620';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(x + 20, BY + 52);
        ctx.lineTo(x + 32, BY + 34);
        ctx.lineTo(x + 95, BY + 34);
        ctx.lineTo(x + 118, BY + 52);
        ctx.closePath();
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(x + 42, BY + 58, 7, 0, Math.PI * 2);
        ctx.arc(x + 98, BY + 58, 7, 0, Math.PI * 2);
        ctx.stroke();
        // Label
        ctx.fillStyle = '#2a2620';
        ctx.font = '11px -apple-system, sans-serif';
        ctx.fillText(labels[i], x + 12, BY + 76);
        if (i === hi) {
          ctx.strokeStyle = '#b89668';
          ctx.lineWidth = 3;
          roundRect(ctx, x - 3, BY - 3, 146, 84, 12);
          ctx.stroke();
        }
      }
    } else if (idx === 1) {
      // Three form lines "typing"
      const lines = [
        ['NAME',         'Pramish Yadav'],
        ['MOBILE',       '+971 • 5● ●●● ●●●●'],
        ['EMIRATES ID',  '784-●●●●-●●●●●●●-●'],
      ];
      lines.forEach((ln, i) => {
        const y = BY + i * 36;
        ctx.fillStyle = '#6e665c';
        ctx.font = '10px -apple-system, sans-serif';
        ctx.fillText(ln[0], 30, y + 12);
        ctx.fillStyle = '#2a2620';
        ctx.font = '15px -apple-system, sans-serif';
        const rev = Math.max(0, localT * 1.5 - i * 0.28);
        const chars = Math.floor(ln[1].length * Math.min(1, rev));
        ctx.fillText(ln[1].slice(0, chars), 30, y + 30);
        ctx.strokeStyle = '#c9bca4';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(30, y + 34);
        ctx.lineTo(W - 30, y + 34);
        ctx.stroke();
      });
    } else if (idx === 2) {
      // Three plans; "Comfort" selected
      const plans = [
        { name: 'Essential', price: 'AED 1,240', tag: 'Third-party' },
        { name: 'Comfort',   price: 'AED 1,890', tag: 'Most popular' },
        { name: 'Complete',  price: 'AED 2,450', tag: 'Full cover' },
      ];
      plans.forEach((p, i) => {
        const x = 30 + i * 160;
        const selected = i === 1;
        ctx.fillStyle = selected ? '#f5ecdc' : '#fff8ea';
        roundRect(ctx, x, BY, 140, 92, 10);
        ctx.fill();
        ctx.strokeStyle = selected ? '#b89668' : '#c9bca4';
        ctx.lineWidth = selected ? 2.5 : 1;
        roundRect(ctx, x, BY, 140, 92, 10);
        ctx.stroke();
        ctx.fillStyle = '#2a2620';
        ctx.font = 'italic 16px Georgia, serif';
        ctx.fillText(p.name, x + 14, BY + 26);
        ctx.font = 'bold 14px -apple-system, sans-serif';
        ctx.fillText(p.price, x + 14, BY + 52);
        ctx.fillStyle = '#6e665c';
        ctx.font = '10px -apple-system, sans-serif';
        ctx.fillText('per year', x + 14 + 74, BY + 52);
        ctx.fillStyle = selected ? '#b89668' : '#a69887';
        ctx.font = '10px -apple-system, sans-serif';
        ctx.fillText(p.tag.toUpperCase(), x + 14, BY + 78);
      });
    } else {
      // Confirmation: growing circle + check
      const cx = W / 2, cy = BY + 36;
      const r = 22 + Math.min(10, localT * 40);
      ctx.fillStyle = '#b89668';
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = '#f5ecdc';
      ctx.lineWidth = 5;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(cx - 12, cy + 1);
      ctx.lineTo(cx - 3, cy + 11);
      ctx.lineTo(cx + 14, cy - 9);
      ctx.stroke();
      ctx.fillStyle = '#2a2620';
      ctx.font = 'italic 17px Georgia, serif';
      ctx.textAlign = 'center';
      ctx.fillText("You're covered.", cx, cy + 68);
      ctx.fillStyle = '#6e665c';
      ctx.font = '12px -apple-system, sans-serif';
      ctx.fillText('Policy · SHY-2026-04-20-847', cx, cy + 88);
      ctx.textAlign = 'left';
    }
  }

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

  draw(0);

  return {
    texture,
    tick(t) {
      if (baseT === null) baseT = t;
      draw(t - baseT);
    },
  };
}
