// Shory World — main bootstrap.
// Creates renderer/scene/camera/lights, builds the Al Maryah neighborhood
// + the Cozy Loft interior + ambient life (traffic, walking dog, strolling
// cat, animated policy-purchase monitor), wires the UI (activity picker,
// time-of-day, orbit), and drives the render loop. Phase 1a — no player
// car, no quests yet.

import * as THREE from 'https://unpkg.com/three@0.128.0/build/three.module.js';
import { buildMaterials } from './materials.js';
import { buildLoft, tickLoft } from './loft.js';
import { buildWorld, DESTINATIONS } from './world.js';
import { buildAmbient, tickAmbient } from './ambient.js';
import { createPolicySim } from './policysim.js';

const stage = document.getElementById('stage');
const W = () => stage.clientWidth;
const H = () => stage.clientHeight;

// --- Renderer ---
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(W(), H());
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputEncoding = THREE.sRGBEncoding;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
stage.appendChild(renderer.domElement);

// --- Scene ---
const scene = new THREE.Scene();
scene.background = new THREE.Color('#f3ece0');
scene.fog = new THREE.Fog('#f3ece0', 55, 140);

// --- Camera with orbit controls ---
const camera = new THREE.PerspectiveCamera(38, W() / H(), 0.1, 400);
const cam = {
  radius: 55,
  theta: Math.PI * 0.30,
  phi: Math.PI * 0.38,
  target: new THREE.Vector3(0, 4, 18),
};
function applyCam() {
  camera.position.set(
    cam.target.x + cam.radius * Math.sin(cam.phi) * Math.cos(cam.theta),
    cam.target.y + cam.radius * Math.cos(cam.phi),
    cam.target.z + cam.radius * Math.sin(cam.phi) * Math.sin(cam.theta)
  );
  camera.lookAt(cam.target);
}
applyCam();

// --- Lights ---
const ambient = new THREE.AmbientLight('#ffffff', 0.45);
scene.add(ambient);
const hemi = new THREE.HemisphereLight('#ffd8a8', '#3b2e24', 0.6);
scene.add(hemi);
const sun = new THREE.DirectionalLight('#ffd59a', 1.1);
sun.position.set(-30, 45, 20);
sun.castShadow = true;
sun.shadow.mapSize.set(1024, 1024);
sun.shadow.camera.left = -55;
sun.shadow.camera.right = 55;
sun.shadow.camera.top = 55;
sun.shadow.camera.bottom = -55;
sun.shadow.camera.near = 1;
sun.shadow.camera.far = 120;
sun.shadow.bias = -0.0005;
scene.add(sun);
const warmFill = new THREE.PointLight('#ffc27a', 0.6, 25, 2);
warmFill.position.set(2, 4, -2);
scene.add(warmFill);
const pendant = new THREE.PointLight('#ffb974', 0, 12, 2);
pendant.position.set(0, 4.2, 0);
scene.add(pendant);

// --- Build materials + world + loft + ambient ---
const M = buildMaterials(THREE);
buildWorld(scene, THREE, M);
const loftRefs = buildLoft(scene, THREE, M);
const ambientRefs = buildAmbient(scene, THREE, M);

// --- Wire the loft monitor to the animated policy-purchase demo ---
const policySim = createPolicySim(THREE);
loftRefs.monScreen.material = new THREE.MeshBasicMaterial({ map: policySim.texture });

// --- UI state ---
const state = {
  activity: null,       // 'tour' | 'traffic' | 'dog' | 'cat' | 'policy' | null
  tour: null,           // tour sub-state
  autoRotate: true,
  dragging: false, lastX: 0, lastY: 0,
  timeOfDay: 'dusk',
};

function setTimeOfDay(t) {
  state.timeOfDay = t;
  if (t === 'day') {
    ambient.intensity = 0.7; hemi.color.set('#cfe6ff'); hemi.intensity = 0.9;
    sun.color.set('#ffffff'); sun.intensity = 1.6; sun.position.set(-30, 55, 20);
    warmFill.intensity = 0.2; pendant.intensity = 0;
    M.lampBulb.emissiveIntensity = 0; M.lampShade.emissiveIntensity = 0;
    M.lampGlow.emissiveIntensity = 0;
    M.headlamp.emissiveIntensity = 0.2;
    scene.background = new THREE.Color('#f3efe6'); scene.fog.color.set('#f3efe6');
    setCap('Midday · 12:08');
  } else if (t === 'dusk') {
    ambient.intensity = 0.45; hemi.color.set('#ffd8a8'); hemi.intensity = 0.6;
    sun.color.set('#ffb374'); sun.intensity = 1.1; sun.position.set(-40, 25, 20);
    warmFill.intensity = 0.6; pendant.intensity = 0.4;
    M.lampBulb.emissiveIntensity = 0.3; M.lampShade.emissiveIntensity = 0.1;
    M.lampGlow.emissiveIntensity = 0.4;
    M.headlamp.emissiveIntensity = 0.5;
    scene.background = new THREE.Color('#f3ece0'); scene.fog.color.set('#f3ece0');
    setCap('Golden hour · 17:42');
  } else {
    ambient.intensity = 0.18; hemi.color.set('#3a4a6a'); hemi.intensity = 0.35;
    sun.color.set('#4a5a8a'); sun.intensity = 0.2;
    warmFill.intensity = 1.0; pendant.intensity = 1.4;
    M.lampBulb.emissiveIntensity = 1.2; M.lampShade.emissiveIntensity = 0.4;
    M.lampGlow.emissiveIntensity = 1.1;
    M.headlamp.emissiveIntensity = 1.1;
    scene.background = new THREE.Color('#1a1a24'); scene.fog.color.set('#1a1a24');
    setCap('Late night · 23:18');
  }
  document.getElementById('btnDay').classList.toggle('on', t === 'day');
  document.getElementById('btnDusk').classList.toggle('on', t === 'dusk');
  document.getElementById('btnNight').classList.toggle('on', t === 'night');
}

function setCap(txt) {
  document.getElementById('cap').textContent = txt;
}

// --- Activity picker ---
// Activities drive the camera: Tour cycles destinations; Traffic/Dog/Cat
// follow a subject; Policy frames the loft monitor. Clicking an active
// chip again drops back to free orbit.
const ACTIVITIES = {
  traffic: {
    label: 'Promenade traffic',
    desc: 'Sedans cycle the Al Maryah Promenade loop in both directions.',
    follow: () => ({
      pos: ambientRefs.cars[0].group.position,
      yOffset: 1.6, radius: 11, phi: Math.PI * 0.40,
    }),
  },
  dog: {
    label: 'Evening walk',
    desc: 'The neighborhood dachshund does her promenade circuit.',
    follow: () => ({
      pos: ambientRefs.walkDog.group.position,
      yOffset: 0.9, radius: 5.5, phi: Math.PI * 0.40,
    }),
  },
  cat: {
    label: 'Café Mira cat',
    desc: 'A stray patrols Café Mira during the warm hours.',
    follow: () => ({
      pos: ambientRefs.walkCat.group.position,
      yOffset: 0.7, radius: 5, phi: Math.PI * 0.42,
    }),
  },
  policy: {
    label: 'Buying a policy',
    desc: 'Someone is walking through Shory\'s 4-step car-insurance flow on the HQ desktop.',
    follow: () => ({
      pos: new THREE.Vector3(loftRefs.monitor.x, loftRefs.monitor.y, loftRefs.monitor.z),
      yOffset: 0, radius: 4.8, phi: Math.PI * 0.48, theta: Math.PI * 0.5,
    }),
  },
};

function setActivity(name) {
  // Toggle off if same activity clicked
  if (state.activity === name) {
    clearActivity();
    return;
  }
  clearActivity();
  state.activity = name;
  state.autoRotate = false;
  document.getElementById('btnRotate').classList.remove('on');

  if (name === 'tour') {
    startTour();
    return;
  }
  const a = ACTIVITIES[name];
  if (!a) return;
  document.getElementById(`btn_${name}`).classList.add('on');
  setSceneCard(a.label, a.desc);
}

function clearActivity() {
  if (state.activity === 'tour') stopTour();
  state.activity = null;
  ['traffic', 'dog', 'cat', 'policy'].forEach(k => {
    const el = document.getElementById(`btn_${k}`);
    if (el) el.classList.remove('on');
  });
  document.getElementById('btnTour').classList.remove('on');
}

// --- Tour: smoothly orbit over each destination for a few seconds ---
const TOUR_STOPS = [
  { key: 'hq',      pos: [0, 4, 18],   radius: 48, theta: Math.PI * 0.30 },
  { key: 'cafe',    pos: [26, 4, 28],  radius: 28, theta: Math.PI * 0.10 },
  { key: 'tower',   pos: [-26, 6, 28], radius: 32, theta: Math.PI * 0.70 },
  { key: 'parking', pos: [0, 2, 46],   radius: 30, theta: Math.PI * 0.50 },
];
function startTour() {
  state.activity = 'tour';
  state.tour = { idx: 0, stopStart: performance.now(), from: serializeCam(), to: serializeStop(TOUR_STOPS[0]) };
  document.getElementById('btnTour').classList.add('on');
  updateSceneCardKey(TOUR_STOPS[0].key);
}
function stopTour() {
  state.tour = null;
  state.activity = null;
  document.getElementById('btnTour').classList.remove('on');
  updateSceneCardKey('hq');
}
function serializeCam() {
  return { tx: cam.target.x, ty: cam.target.y, tz: cam.target.z, r: cam.radius, theta: cam.theta, phi: cam.phi };
}
function serializeStop(s) {
  return { tx: s.pos[0], ty: s.pos[1], tz: s.pos[2], r: s.radius, theta: s.theta, phi: Math.PI * 0.35 };
}
function lerp(a, b, t) { return a + (b - a) * t; }
function advanceTour(nowMs) {
  const T = 3500;
  const el = nowMs - state.tour.stopStart;
  const k = Math.min(1, el / T);
  const e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
  const f = state.tour.from, to = state.tour.to;
  cam.target.set(lerp(f.tx, to.tx, e), lerp(f.ty, to.ty, e), lerp(f.tz, to.tz, e));
  cam.radius = lerp(f.r, to.r, e);
  cam.theta  = lerp(f.theta, to.theta, e);
  cam.phi    = lerp(f.phi, to.phi, e);
  applyCam();
  if (k >= 1) {
    const next = state.tour.idx + 1;
    if (next >= TOUR_STOPS.length) {
      clearActivity();
      return;
    }
    state.tour.idx = next;
    state.tour.stopStart = nowMs;
    state.tour.from = serializeCam();
    state.tour.to = serializeStop(TOUR_STOPS[next]);
    updateSceneCardKey(TOUR_STOPS[next].key);
  }
}

// Smooth-follow camera for Traffic / Dog / Cat / Policy activities.
function followSubject(dt) {
  const spec = ACTIVITIES[state.activity].follow();
  const k = 1 - Math.pow(0.08, dt);
  cam.target.x = lerp(cam.target.x, spec.pos.x, k);
  cam.target.y = lerp(cam.target.y, spec.pos.y + spec.yOffset, k);
  cam.target.z = lerp(cam.target.z, spec.pos.z, k);
  cam.radius = lerp(cam.radius, spec.radius, k);
  cam.phi    = lerp(cam.phi, spec.phi, k);
  if (spec.theta !== undefined) {
    cam.theta = lerp(cam.theta, spec.theta, k);
  } else {
    cam.theta += 0.0008; // gentle orbital drift
  }
  applyCam();
}

function setSceneCard(ttl, desc) {
  document.getElementById('sceneTtl').textContent = ttl;
  document.getElementById('sceneDesc').textContent = desc;
}
function updateSceneCardKey(key) {
  const copy = {
    hq:      { ttl: 'Shory HQ · Al Maryah Island', desc: 'Ground-floor loft, second-floor offices. Your home base in Shory World.' },
    cafe:    { ttl: 'Café Mira', desc: 'Waterfront café on the promenade. Safe Arrival quest lands here.' },
    tower:   { ttl: "Friend's Tower", desc: 'Residential tower. Lock-your-home quest starts before you leave HQ; dropping by here completes it.' },
    parking: { ttl: 'Al Maryah Parking', desc: 'Across Al Falah St. Hone your parking — defensive-driving bonus.' },
  };
  const c = copy[key] || copy.hq;
  setSceneCard(c.ttl, c.desc);
}

// --- UI wiring ---
document.getElementById('btnDay').onclick   = () => setTimeOfDay('day');
document.getElementById('btnDusk').onclick  = () => setTimeOfDay('dusk');
document.getElementById('btnNight').onclick = () => setTimeOfDay('night');
document.getElementById('btnRotate').onclick = () => {
  state.autoRotate = !state.autoRotate;
  document.getElementById('btnRotate').classList.toggle('on', state.autoRotate);
  if (state.autoRotate) clearActivity();
};
document.getElementById('btnReset').onclick = () => {
  clearActivity();
  cam.theta = Math.PI * 0.30; cam.phi = Math.PI * 0.38; cam.radius = 55;
  cam.target.set(0, 4, 18);
  applyCam();
  updateSceneCardKey('hq');
};
document.getElementById('btnTour').onclick    = () => setActivity('tour');
document.getElementById('btn_traffic').onclick = () => setActivity('traffic');
document.getElementById('btn_dog').onclick     = () => setActivity('dog');
document.getElementById('btn_cat').onclick     = () => setActivity('cat');
document.getElementById('btn_policy').onclick  = () => setActivity('policy');

// --- Orbit drag + wheel zoom ---
const canvas = renderer.domElement;
function onDown(e) {
  const p = e.touches ? e.touches[0] : e;
  state.dragging = true;
  state.lastX = p.clientX; state.lastY = p.clientY;
  state.autoRotate = false;
  document.getElementById('btnRotate').classList.remove('on');
  clearActivity();
}
function onDragMove(e) {
  if (!state.dragging) return;
  const p = e.touches ? e.touches[0] : e;
  const dx = p.clientX - state.lastX;
  const dy = p.clientY - state.lastY;
  state.lastX = p.clientX; state.lastY = p.clientY;
  cam.theta -= dx * 0.006;
  cam.phi = Math.max(0.15, Math.min(1.45, cam.phi - dy * 0.005));
  applyCam();
}
function onUp() { state.dragging = false; }
function onWheel(e) {
  e.preventDefault();
  cam.radius = Math.max(15, Math.min(90, cam.radius + e.deltaY * 0.04));
  applyCam();
}
canvas.addEventListener('mousedown', onDown);
canvas.addEventListener('mousemove', onDragMove);
window.addEventListener('mouseup', onUp);
canvas.addEventListener('touchstart', onDown, { passive: true });
canvas.addEventListener('touchmove', onDragMove, { passive: true });
canvas.addEventListener('touchend', onUp);
canvas.addEventListener('wheel', onWheel, { passive: false });

window.addEventListener('resize', () => {
  renderer.setSize(W(), H());
  camera.aspect = W() / H();
  camera.updateProjectionMatrix();
});

// --- Init ---
setTimeOfDay('dusk');
updateSceneCardKey('hq');

// --- Render loop ---
const clock = new THREE.Clock();
function tick() {
  const t = clock.getElapsedTime();
  const dt = Math.min(0.05, clock.getDelta());

  if (state.activity === 'tour') {
    advanceTour(performance.now());
  } else if (state.activity) {
    followSubject(dt);
  } else if (state.autoRotate) {
    cam.theta += 0.0015;
    applyCam();
  }

  tickLoft(loftRefs, t, dt);
  tickAmbient(ambientRefs, t, dt);
  policySim.tick(t);

  renderer.render(scene, camera);
  requestAnimationFrame(tick);
}
tick();
