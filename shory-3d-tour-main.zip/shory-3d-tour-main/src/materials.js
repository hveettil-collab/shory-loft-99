// Shared material palette for Shory World.
// Interior (loft) materials lifted from the Cozy Loft prototype; exterior
// materials added for the Al Maryah Island neighborhood.
// All colors hand-picked to stay inside the warm cream/ink palette —
// no neon, no saturated brights. Muted tones only.

export function buildMaterials(THREE) {
  return {
    // --- Loft / interior ---
    wall:      new THREE.MeshStandardMaterial({ color: '#e9dcc7', roughness: 0.95 }),
    floorLt:   new THREE.MeshStandardMaterial({ color: '#c99a6b', roughness: 0.75 }),
    floorDk:   new THREE.MeshStandardMaterial({ color: '#a67548', roughness: 0.75 }),
    wood:      new THREE.MeshStandardMaterial({ color: '#7a5235', roughness: 0.6 }),
    woodLt:    new THREE.MeshStandardMaterial({ color: '#b58863', roughness: 0.7 }),
    metal:     new THREE.MeshStandardMaterial({ color: '#2b2b2b', roughness: 0.35, metalness: 0.7 }),
    black:     new THREE.MeshStandardMaterial({ color: '#1a1a1a', roughness: 0.6 }),
    screen:    new THREE.MeshStandardMaterial({ color: '#0a0a0a', emissive: '#5a7a9a', emissiveIntensity: 0.35 }),
    couch:     new THREE.MeshStandardMaterial({ color: '#8a9a8a', roughness: 0.9 }),
    pillowA:   new THREE.MeshStandardMaterial({ color: '#d9a87a', roughness: 0.95 }),
    pillowB:   new THREE.MeshStandardMaterial({ color: '#c76e4a', roughness: 0.95 }),
    rug:       new THREE.MeshStandardMaterial({ color: '#b8564a', roughness: 1 }),
    leaf:      new THREE.MeshStandardMaterial({ color: '#4e7a4e', roughness: 0.85 }),
    leafLt:    new THREE.MeshStandardMaterial({ color: '#6a9a6a', roughness: 0.85 }),
    pot:       new THREE.MeshStandardMaterial({ color: '#b58160', roughness: 0.9 }),
    glass:     new THREE.MeshPhysicalMaterial({ color: '#cfe6f2', roughness: 0.05, transmission: 0.6, transparent: true, opacity: 0.5 }),
    lampShade: new THREE.MeshStandardMaterial({ color: '#f5e3b8', emissive: '#ffb974', emissiveIntensity: 0 }),
    lampBulb:  new THREE.MeshStandardMaterial({ color: '#fff0c8', emissive: '#ffb974', emissiveIntensity: 0 }),
    frame:     new THREE.MeshStandardMaterial({ color: '#3a2a1e', roughness: 0.6 }),
    posterBg:  new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.85 }),

    // --- Pets ---
    catFur:    new THREE.MeshStandardMaterial({ color: '#2a2a2a', roughness: 0.95 }),
    catBelly:  new THREE.MeshStandardMaterial({ color: '#f5f0e8', roughness: 0.95 }),
    catNose:   new THREE.MeshStandardMaterial({ color: '#d48a8a', roughness: 0.7 }),
    dogFur:    new THREE.MeshStandardMaterial({ color: '#c7a074', roughness: 0.95 }),
    dogBelly:  new THREE.MeshStandardMaterial({ color: '#e8d5b8', roughness: 0.95 }),
    dogNose:   new THREE.MeshStandardMaterial({ color: '#1a1a1a', roughness: 0.5 }),
    collar:    new THREE.MeshStandardMaterial({ color: '#c04040', roughness: 0.6 }),
    tag:       new THREE.MeshStandardMaterial({ color: '#d4af37', metalness: 0.8, roughness: 0.3 }),
    eye:       new THREE.MeshStandardMaterial({ color: '#1a1a1a' }),
    eyeGreen:  new THREE.MeshStandardMaterial({ color: '#7ad67a', emissive: '#4a8a4a', emissiveIntensity: 0.3 }),

    // --- Dog's toy car (stays in loft as cameo) ---
    carBody:   new THREE.MeshStandardMaterial({ color: '#d94a3d', roughness: 0.4, metalness: 0.3 }),
    carWindow: new THREE.MeshPhysicalMaterial({ color: '#88b4c8', roughness: 0.1, transmission: 0.4, transparent: true, opacity: 0.65 }),
    tire:      new THREE.MeshStandardMaterial({ color: '#1a1a1a', roughness: 0.9 }),
    rim:       new THREE.MeshStandardMaterial({ color: '#d0d0d0', roughness: 0.3, metalness: 0.8 }),
    headlamp:  new THREE.MeshStandardMaterial({ color: '#fff8d0', emissive: '#fff5b0', emissiveIntensity: 0.5 }),
    tailLight: new THREE.MeshStandardMaterial({ color: '#ff3a2a', emissive: '#ff3a2a', emissiveIntensity: 0.4 }),

    // --- Toys ---
    ball:      new THREE.MeshStandardMaterial({ color: '#ffce3a', roughness: 0.7 }),
    featherA:  new THREE.MeshStandardMaterial({ color: '#a8d0e8', roughness: 0.9 }),
    featherB:  new THREE.MeshStandardMaterial({ color: '#e8a8c8', roughness: 0.9 }),

    // --- Exterior (Al Maryah Island) ---
    ground:    new THREE.MeshStandardMaterial({ color: '#e8dcc4', roughness: 0.95 }), // sand/stone plaza
    road:      new THREE.MeshStandardMaterial({ color: '#d4c4a8', roughness: 0.9 }),  // warm asphalt
    roadLine:  new THREE.MeshStandardMaterial({ color: '#f0e6d2', roughness: 0.8 }),  // faded markings
    curb:      new THREE.MeshStandardMaterial({ color: '#c9bca3', roughness: 0.9 }),
    facadeCream: new THREE.MeshStandardMaterial({ color: '#efe4d0', roughness: 0.85 }),
    facadeSand:  new THREE.MeshStandardMaterial({ color: '#dcc8a8', roughness: 0.9 }),
    facadeStone: new THREE.MeshStandardMaterial({ color: '#c8b898', roughness: 0.95 }),
    roofTerracotta: new THREE.MeshStandardMaterial({ color: '#c97a4a', roughness: 0.8 }),
    awning:    new THREE.MeshStandardMaterial({ color: '#a85a3a', roughness: 0.85 }),
    glassPanel:new THREE.MeshPhysicalMaterial({ color: '#c4d8dc', roughness: 0.2, metalness: 0.1, transmission: 0.3, transparent: true, opacity: 0.75 }),
    water:     new THREE.MeshStandardMaterial({ color: '#a8c4d0', roughness: 0.3, metalness: 0.2 }),
    palmTrunk: new THREE.MeshStandardMaterial({ color: '#8a6a4a', roughness: 0.9 }),
    palmFrond: new THREE.MeshStandardMaterial({ color: '#6a8a5a', roughness: 0.85 }),
    shrub:     new THREE.MeshStandardMaterial({ color: '#7a9a6a', roughness: 0.9 }),
    signBg:    new THREE.MeshStandardMaterial({ color: '#1a1915', roughness: 0.6 }),
    streetlamp:new THREE.MeshStandardMaterial({ color: '#3a3028', roughness: 0.7, metalness: 0.3 }),
    lampGlow:  new THREE.MeshStandardMaterial({ color: '#fff0c8', emissive: '#ffb974', emissiveIntensity: 0 }),
  };
}
