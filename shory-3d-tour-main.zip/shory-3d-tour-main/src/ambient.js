// Ambient life on Al Maryah Island — moving cars, a walking dog on the
// promenade, and a stray cat strolling around Café Mira. Pure background
// motion; nothing interactive yet. Buildworld() + buildLoft() are already
// in place, so this module adds *on top* of that world without touching it.
//
// Traffic routing assumes right-hand drive (UAE):
//   Al Maryah Promenade (E-W at z=18, width 8):
//     eastbound  on southern lane (z=20)
//     westbound  on northern lane (z=16)
//   Al Falah St (N-S at x=0, width 8, z∈[16,48]):
//     southbound on eastern lane (x=+2)
//     northbound on western lane (x=-2)

export function buildAmbient(scene, THREE, M) {
  // --- Cars cycling the two roads ---
  const ROUTES = [
    { axis: 'x', lane: 20, dir: +1, speed: 4.2, color: '#e8dcc4', start: -55 },
    { axis: 'x', lane: 16, dir: -1, speed: 5.0, color: '#b8a58a', start:  55 },
    { axis: 'z', lane:  2, dir: +1, speed: 4.5, color: '#d4b8a0', start:  17 },
    { axis: 'z', lane: -2, dir: -1, speed: 4.0, color: '#9a8a74', start:  47 },
  ];
  const cars = ROUTES.map(r => {
    const c = makeCar(THREE, r.color);
    c.group.position.set(
      r.axis === 'x' ? r.start : r.lane,
      0,
      r.axis === 'z' ? r.start : r.lane,
    );
    c.group.rotation.y = headingFor(r.axis, r.dir);
    scene.add(c.group);
    return { ...c, route: r };
  });

  // --- Walking dachshund on the promenade sidewalk (z = 24, south side) ---
  const walkDog = makeWalkDog(THREE, M);
  walkDog.group.position.set(-20, 0, 24);
  scene.add(walkDog.group);

  // --- Stray cat lazily patrolling Café Mira (center 26, 28) ---
  const walkCat = makeWalkCat(THREE, M);
  walkCat.group.position.set(26 + 7, 0, 28);
  scene.add(walkCat.group);

  return { cars, walkDog, walkCat };
}

export function tickAmbient(refs, t, dt) {
  // --- Cars ---
  const AXIS_BOUNDS = { x: [-58, 58], z: [16, 48] };
  for (const c of refs.cars) {
    const r = c.route;
    const pos = c.group.position;
    if (r.axis === 'x') {
      pos.x += r.dir * r.speed * dt;
      const [lo, hi] = AXIS_BOUNDS.x;
      if (r.dir > 0 && pos.x > hi) pos.x = lo;
      if (r.dir < 0 && pos.x < lo) pos.x = hi;
    } else {
      pos.z += r.dir * r.speed * dt;
      const [lo, hi] = AXIS_BOUNDS.z;
      if (r.dir > 0 && pos.z > hi) pos.z = lo;
      if (r.dir < 0 && pos.z < lo) pos.z = hi;
    }
    // Wheels spin (wheels face sideways, so rotate local X)
    const spin = dt * r.speed * 3 * r.dir;
    c.wheels.forEach(w => { w.rotation.y -= spin; });
  }

  // --- Walking dog: ping-pong on the promenade sidewalk ---
  const dogPeriod = 40; // seconds for full round trip
  const dogPhase = ((t % dogPeriod) / dogPeriod) * 2; // 0..2
  const dogX = dogPhase < 1
    ? -25 + dogPhase * 50
    :  25 - (dogPhase - 1) * 50;
  refs.walkDog.group.position.x = dogX;
  refs.walkDog.group.position.z = 24;
  refs.walkDog.group.rotation.y = dogPhase < 1 ? -Math.PI / 2 : Math.PI / 2;
  animateQuadLegs(refs.walkDog.legs, t, 7, 0.45);
  refs.walkDog.tailG.rotation.z = Math.PI / 2.5 + Math.sin(t * 6) * 0.25;
  refs.walkDog.earL.rotation.x = Math.sin(t * 5) * 0.12;
  refs.walkDog.earR.rotation.x = Math.sin(t * 5 + 0.4) * 0.12;
  // Slight body bob
  refs.walkDog.bodyG.position.y = Math.abs(Math.sin(t * 7)) * 0.04;

  // --- Strolling cat: slow loop around Café Mira ---
  const catCenter = { x: 26, z: 28 };
  const catRadius = 7.2;
  const catAngle = (t * 0.15) % (Math.PI * 2);
  const catX = catCenter.x + Math.cos(catAngle) * catRadius;
  const catZ = catCenter.z + Math.sin(catAngle) * catRadius;
  refs.walkCat.group.position.set(catX, 0, catZ);
  // Tangent heading (cat walks CCW facing along its tangent)
  refs.walkCat.group.rotation.y = -catAngle - Math.PI / 2;
  animateQuadLegs(refs.walkCat.legs, t, 5, 0.35);
  // Swishing tail
  refs.walkCat.tailSegs.forEach((s, i) => {
    s.position.set(-0.1 * (i + 1), 0.04 + i * 0.015, Math.sin(t * 2.5 + i * 0.45) * 0.09);
  });
  refs.walkCat.tailG.rotation.y = Math.sin(t * 1.3) * 0.25;
}

// ------------------------------------------------------------------
// Model factories
// ------------------------------------------------------------------

function makeCar(THREE, color) {
  const g = new THREE.Group();
  const body = new THREE.MeshStandardMaterial({ color, roughness: 0.55 });
  const roof = new THREE.MeshStandardMaterial({ color: shade(color, -0.08), roughness: 0.55 });
  const glass = new THREE.MeshStandardMaterial({
    color: '#2a3844', roughness: 0.25, metalness: 0.3,
  });
  const tire = new THREE.MeshStandardMaterial({ color: '#1d1d1d', roughness: 0.9 });
  const rim  = new THREE.MeshStandardMaterial({ color: '#a8a29a', metalness: 0.6, roughness: 0.5 });
  const hl   = new THREE.MeshStandardMaterial({
    color: '#fff7dc', emissive: '#ffe9b4', emissiveIntensity: 0.8, roughness: 0.4,
  });
  const tl   = new THREE.MeshStandardMaterial({
    color: '#8a2a2a', emissive: '#b23030', emissiveIntensity: 0.6, roughness: 0.5,
  });

  const chassis = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.55, 1.5), body);
  chassis.position.y = 0.55;
  chassis.castShadow = chassis.receiveShadow = true;
  g.add(chassis);
  const cabin = new THREE.Mesh(new THREE.BoxGeometry(1.9, 0.65, 1.4), roof);
  cabin.position.set(-0.15, 1.15, 0);
  cabin.castShadow = true;
  g.add(cabin);
  // Side windows (darker)
  [-0.73, 0.73].forEach(wz => {
    const win = new THREE.Mesh(new THREE.BoxGeometry(1.78, 0.55, 0.04), glass);
    win.position.set(-0.15, 1.15, wz);
    g.add(win);
  });
  // Windshield + rear window
  const wf = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.55, 1.35), glass);
  wf.position.set(0.82, 1.15, 0);
  wf.rotation.z = -0.25;
  g.add(wf);
  const wb = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.5, 1.35), glass);
  wb.position.set(-1.12, 1.15, 0);
  wb.rotation.z = 0.3;
  g.add(wb);
  // Headlights
  [-0.55, 0.55].forEach(hz => {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 10), hl);
    m.position.set(1.6, 0.55, hz);
    g.add(m);
  });
  // Tail lights
  [-0.55, 0.55].forEach(tz => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.12, 0.2), tl);
    m.position.set(-1.6, 0.55, tz);
    g.add(m);
  });
  // Wheels
  const wheelGeo = new THREE.CylinderGeometry(0.33, 0.33, 0.22, 16);
  const rimGeo   = new THREE.CylinderGeometry(0.17, 0.17, 0.24, 12);
  const wheels = [];
  [[1.05, -0.78], [1.05, 0.78], [-1.05, -0.78], [-1.05, 0.78]].forEach(([wx, wz]) => {
    const wg = new THREE.Group();
    wg.position.set(wx, 0.33, wz);
    const t = new THREE.Mesh(wheelGeo, tire);
    t.rotation.x = Math.PI / 2;
    t.castShadow = true;
    wg.add(t);
    const r = new THREE.Mesh(rimGeo, rim);
    r.rotation.x = Math.PI / 2;
    wg.add(r);
    g.add(wg);
    wheels.push(wg);
  });
  return { group: g, wheels };
}

function makeWalkDog(THREE, M) {
  const g = new THREE.Group();
  const bodyG = new THREE.Group();
  g.add(bodyG);
  const torso = new THREE.Mesh(new THREE.SphereGeometry(0.3, 18, 14), M.dogFur);
  torso.scale.set(1.4, 0.9, 1);
  torso.position.y = 0.55;
  torso.castShadow = true;
  bodyG.add(torso);
  const belly = new THREE.Mesh(new THREE.SphereGeometry(0.22, 14, 10), M.dogBelly);
  belly.scale.set(1.3, 0.65, 0.9);
  belly.position.y = 0.45;
  bodyG.add(belly);

  const headG = new THREE.Group();
  headG.position.set(0.42, 0.75, 0);
  bodyG.add(headG);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.23, 16, 12), M.dogFur);
  head.castShadow = true;
  headG.add(head);
  const snout = new THREE.Mesh(new THREE.SphereGeometry(0.13, 12, 10), M.dogBelly);
  snout.scale.set(1.2, 0.8, 0.9);
  snout.position.set(0.18, -0.06, 0);
  headG.add(snout);
  const nose = new THREE.Mesh(new THREE.SphereGeometry(0.045, 8, 8), M.dogNose);
  nose.position.set(0.3, -0.04, 0);
  headG.add(nose);
  [[0.14, 0.08, -0.11], [0.14, 0.08, 0.11]].forEach(([ex, ey, ez]) => {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.033, 10, 10), M.eye);
    e.position.set(ex, ey, ez);
    headG.add(e);
  });
  const earGeo = new THREE.SphereGeometry(0.1, 10, 8);
  const earL = new THREE.Mesh(earGeo, M.dogFur);
  earL.scale.set(0.45, 1.1, 0.7);
  earL.position.set(-0.12, 0.08, -0.22);
  headG.add(earL);
  const earR = new THREE.Mesh(earGeo, M.dogFur);
  earR.scale.set(0.45, 1.1, 0.7);
  earR.position.set(-0.12, 0.08, 0.22);
  headG.add(earR);

  const legs = [];
  [[0.22, -0.2], [0.22, 0.2], [-0.22, -0.2], [-0.22, 0.2]].forEach(([lx, lz]) => {
    const legG = new THREE.Group();
    legG.position.set(lx, 0.4, lz);
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.4, 8), M.dogFur);
    leg.position.y = -0.18;
    leg.castShadow = true;
    legG.add(leg);
    bodyG.add(legG);
    legs.push(legG);
  });

  const tailG = new THREE.Group();
  tailG.position.set(-0.33, 0.7, 0);
  bodyG.add(tailG);
  const tail = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.02, 0.35, 8), M.dogFur);
  tail.position.set(-0.15, 0.08, 0);
  tail.rotation.z = Math.PI / 2.5;
  tailG.add(tail);

  return { group: g, bodyG, headG, legs, tailG, earL, earR };
}

function makeWalkCat(THREE, M) {
  const g = new THREE.Group();
  const bodyG = new THREE.Group();
  g.add(bodyG);
  const torso = new THREE.Mesh(new THREE.SphereGeometry(0.28, 18, 14), M.catFur);
  torso.scale.set(1.35, 0.85, 1);
  torso.position.y = 0.42;
  torso.castShadow = true;
  bodyG.add(torso);
  const belly = new THREE.Mesh(new THREE.SphereGeometry(0.2, 14, 10), M.catBelly);
  belly.scale.set(1.15, 0.6, 0.85);
  belly.position.y = 0.32;
  bodyG.add(belly);

  const headG = new THREE.Group();
  headG.position.set(0.36, 0.55, 0);
  bodyG.add(headG);
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 16, 12), M.catFur);
  head.castShadow = true;
  headG.add(head);
  const catEarGeo = new THREE.ConeGeometry(0.08, 0.17, 10);
  const catEarL = new THREE.Mesh(catEarGeo, M.catFur);
  catEarL.position.set(-0.02, 0.17, -0.1);
  headG.add(catEarL);
  const catEarR = new THREE.Mesh(catEarGeo, M.catFur);
  catEarR.position.set(-0.02, 0.17, 0.1);
  headG.add(catEarR);
  [[0.12, 0.06, -0.085], [0.12, 0.06, 0.085]].forEach(([ex, ey, ez]) => {
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.028, 8, 8), M.eyeGreen);
    e.position.set(ex, ey, ez);
    headG.add(e);
  });
  const nose = new THREE.Mesh(new THREE.SphereGeometry(0.02, 8, 8), M.catNose);
  nose.position.set(0.19, -0.02, 0);
  headG.add(nose);

  const legs = [];
  [[0.18, -0.16], [0.18, 0.16], [-0.18, -0.16], [-0.18, 0.16]].forEach(([lx, lz]) => {
    const legG = new THREE.Group();
    legG.position.set(lx, 0.3, lz);
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.055, 0.055, 0.3, 8), M.catFur);
    leg.position.y = -0.13;
    leg.castShadow = true;
    legG.add(leg);
    bodyG.add(legG);
    legs.push(legG);
  });

  const tailG = new THREE.Group();
  tailG.position.set(-0.32, 0.52, 0);
  bodyG.add(tailG);
  const tailSegs = [];
  for (let i = 0; i < 5; i++) {
    const s = new THREE.Mesh(new THREE.SphereGeometry(0.05, 10, 8), M.catFur);
    s.castShadow = true;
    tailG.add(s);
    tailSegs.push(s);
  }
  return { group: g, bodyG, headG, legs, tailG, tailSegs };
}

// ------------------------------------------------------------------
// Helpers
// ------------------------------------------------------------------

function animateQuadLegs(legs, t, freq, amp) {
  // Trotting: diagonals in phase (0+3 and 1+2)
  legs[0].rotation.x =  Math.sin(t * freq) * amp;
  legs[3].rotation.x =  Math.sin(t * freq) * amp;
  legs[1].rotation.x = -Math.sin(t * freq) * amp;
  legs[2].rotation.x = -Math.sin(t * freq) * amp;
}

function headingFor(axis, dir) {
  if (axis === 'x') return dir > 0 ? 0 : Math.PI;
  return dir > 0 ? -Math.PI / 2 : Math.PI / 2;
}

function shade(hex, amount) {
  const n = parseInt(hex.slice(1), 16);
  const r = Math.max(0, Math.min(255, ((n >> 16) & 0xff) + Math.round(amount * 255)));
  const gg = Math.max(0, Math.min(255, ((n >> 8) & 0xff) + Math.round(amount * 255)));
  const b = Math.max(0, Math.min(255, (n & 0xff) + Math.round(amount * 255)));
  return '#' + ((r << 16) | (gg << 8) | b).toString(16).padStart(6, '0');
}
