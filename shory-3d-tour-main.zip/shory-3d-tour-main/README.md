# Shory World

A playable brand universe for [Shory](https://shory.com) — the UAE digital insurance platform. Shory World invites users to drive through a warm, cozy reimagining of the Al Maryah Island neighborhood (Abu Dhabi), complete insurance-themed quests, earn Shory Points, and redeem real rewards.

Built on Three.js, zero build step, single tiny Node server.

## Status — Phase 1a · World geometry preview

This is the first milestone: the 3D world as a cinematic preview. No player car yet, no quests, no auth. Just the neighborhood and the HQ, so the look and feel can be locked down before gameplay layers on.

Built on top of the earlier `shory-loft` prototype — the cozy interior (dog in a toy car, cat on the rug, animated dust, pendant lamp) is preserved at street level inside Shory HQ.

### What's in the scene
- **Shory HQ** on Al Maryah Island — two-storey cream-and-glass block with the living loft inside.
- **Al Maryah Promenade** (east–west) and **Al Falah Street** (north–south) crossing at HQ.
- **Café Mira** — waterfront café on the promenade (Safe Arrival quest lands here).
- **Friend's Tower** — residential tower (Lock-your-home quest starts before you leave HQ).
- **Al Maryah Parking** — parking lot across Al Falah Street.
- Waterfront sliver, date palms, shrubs, streetlamps, destination markers.

### Lighting
Day · Dusk · Night — each preset retunes ambient / hemisphere / sun / fog / lamp emissives.

## Running locally

No build step. Requires Node.js (any recent version).

```bash
node server.cjs
```

Then open **http://localhost:8765**.

The server is a ~30-line zero-dependency static file server (`server.cjs`).

## Controls
- **Drag** — orbit camera
- **Scroll / pinch** — zoom
- **✦ Tour** — cycle through the four destinations
- **↻ Auto** — auto-rotate the camera
- **⟲ Reset** — back to the HQ hero shot
- **☀ Day · ◐ Dusk · ☾ Night** — time-of-day presets

## File layout

```
shory-world/
├── index.html              # UI shell + styles
├── server.cjs              # Zero-dep static server on :8765
├── src/
│   ├── main.js             # Renderer, camera, lights, UI wiring, render loop
│   ├── world.js            # Al Maryah neighborhood + destinations
│   ├── loft.js             # Cozy Loft interior (dog, cat, car, dust)
│   └── materials.js        # Shared material palette
├── assets/
│   └── shory-logo.js       # SHORY word-mark (base64 JPEG)
└── .claude/
    └── launch.json         # Preview config
```

## Roadmap

- **Phase 1b** — Player car (cream sedan), WASD / arrow / virtual-joystick controls, camera follow, AABB collision.
- **Phase 1c** — Quest system: *Safe Arrival*, *Locked & Loaded*, *Policy Check*. Trigger zones, state machine, completion toasts.
- **Phase 1d** — Points engine + HUD. Bronze / Silver / Gold tiers.
- **Phase 1e** — Phone-OTP auth stub (localStorage session) + Redemption drawer with mock rewards (ADNOC, Shory, Careem).
- **Phase 1f** — QA pass: mobile testing, edge cases, polish.

## A note on the Shory brand

This repo is public to make the work shareable, but **Shory and the Shory word-mark belong to the company**. If you fork or reuse this code, please remove or replace Shory-specific branding (the logo asset, the HQ sign, brand copy) — keep the architecture, ditch the identity.
